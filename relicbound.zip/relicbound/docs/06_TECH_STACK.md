# 06 — Technology Stack & Architecture (ADR-002)
**Supersedes ADR-001 (web-first three.js).** · Date: 2026-11-02 · Status: Accepted

## Decision
**An Android-first native game built in Godot 4 (GDScript).** It ships to Google Play first, then the iOS App
Store. A small **web demo** of World 1 is exported from the same project for marketing.

The rules run as a pure grid simulation that always resolves the same way. The scenes, renderer, VFX and audio
only draw it and react to its events.

### Why
| Factor | Android app (chosen) | Web app |
|---|---|---|
| Audience | The genre's fans played on phones. Android is most phones in our target regions | Mostly desktop and casual portal players |
| Revenue | Google Play Billing; players are used to paying once | Weak unless a portal takes a revenue share |
| Discovery | Store search, charts, featuring | We have to bring every player ourselves |
| Performance | Full GPU and memory → 2.5D lighting, debris, big VFX | Browser memory caps, throttling, audio quirks |
| Offline / feel | Full offline, haptics, gamepad, true fullscreen | Partial |

### Why Godot (and not three.js or Unity)
| Option | Verdict |
|---|---|
| **Godot 4** | ✅ Free (MIT); one-click Android/iOS/Web export; Jolt and Recast built in; 9 of our 10 libraries plug in |
| three.js + Capacitor | ❌ Good for web-first, but Terrain3D and godot_voxel can't be used, and every native library becomes a WASM port |
| Unity | ❌ Licence/runtime fees, heavier builds, less control |

## Engine settings
| Setting | Value |
|---|---|
| Engine | Latest stable **Godot 4.x** (≥ 4.4 for built-in Jolt). Pin the exact version in `project.godot` and CI |
| Language | **GDScript** with static types everywhere (`var x: int`). (C# can't export to the web, and we want the demo) |
| Renderer | **Mobile** renderer (Vulkan) by default; **Compatibility** (OpenGL ES 3) for low-end Android and the web demo |
| Physics | 3D physics engine = **Jolt** (cosmetic only, see rules) |
| Min Android | API 24 (Android 7.0), arm64-v8a + armeabi-v7a; target the latest API that Play requires |
| Packaging | Android App Bundle (`.aab`) for Play; Play Asset Delivery for world packs if the bundle exceeds 150 MB |
| Tests | **GUT** (Godot Unit Test) for headless unit tests |
| CI | GitHub Actions + headless Godot: run tests, check levels, export the `.aab`/`.apk` and the web demo |

## How the 10 libraries fit
| Library | Role in Relicbound | How it gets into Godot | Status |
|---|---|---|---|
| **JoltPhysics** | Cosmetic only: boulder-smash debris, wall crumbles, enemy ragdolls. **Never game rules** | Built into Godot 4.4+ (Project Settings → Physics → 3D → Jolt Physics) | ✅ Core polish |
| **recastnavigation** | Free-walking NPCs in the hub camp and cutscenes. Puzzle enemies use grid A* in the sim | Built into Godot (`NavigationRegion3D` / `NavigationAgent3D` use Recast) | ✅ Hub only |
| **meshoptimizer** | LODs and vertex optimisation at import | Built into Godot's mesh importer (auto LOD). The `gltfpack` CLI is optional for pre-optimising | ✅ Pipeline |
| **pixelfx** | 2D pixel VFX: dust, sparkles, torches, splashes, poofs, UI juice | `node tools/render.mjs <id> --sheet` → PNG + JSON → `AnimatedSprite3D` (billboard, nearest filter). The skill is installed | ✅ Core |
| **Effekseer** | Big 3D VFX: boss attacks, Sunstone reveals, eruptions | **Effekseer for Godot 4** plugin in `addons/effekseer`; author in the Effekseer editor | ✅ Boss/cinematic |
| **Material Maker** | Procedural PBR materials (jade, sandstone, ice, basalt, brass) | Built with Godot; export Godot materials/textures → `assets/materials/` | ✅ Art pipeline |
| **FastNoise2** | Tile wear and moss scatter, background cave walls, daily-room seeds | Through godot_voxel's `FastNoise2` resource, or baked offline to textures. Godot's built-in `FastNoiseLite` covers simple cases | ✅ Tools/variety |
| **Terrain3D** | Outdoor scenes: world map/flight hub, jungle and desert approach vistas in cutscenes | GDExtension in `addons/terrain_3d`. **Puzzle levels don't use it** | ⚪ Hub/cutscenes. Mobile support confirmed in the Week-1 spike |
| **godot_voxel** | Destructible backdrop rock for chase/collapse levels; cave-in sequences | GDExtension build (or a custom engine build with the module) | ⚪ Optional. Decided by the spike; skip it if it costs > 3 MB or 2 ms/frame |
| **ozz-animation** | Not needed | Godot's `AnimationTree` / `AnimationPlayer` cover blending and skinning | ⛔ Not used (kept as reference) |

> Puzzle levels are made from **grid tiles** (`GridMap` / `MultiMeshInstance3D`), not terrain or voxels. Terrain3D
> and godot_voxel are for scenery around the puzzles, so they're optional and can be cut without hurting the game.

## Architecture
```
relicbound/
├─ game/                         # Godot project root (project.godot)
│  ├─ sim/                       # PURE rules: no Node, no scene, no randf()
│  │  ├─ sim_state.gd            #   RefCounted: grid (PackedInt32Array), objects, rng seed, tick
│  │  ├─ sim_step.gd             #   static func step(state, intent) -> StepResult {state, events}
│  │  ├─ rules/                  #   gravity.gd, push.gd, water.gd, sand.gd, ice.gd, lava.gd, gears.gd
│  │  └─ events.gd               #   BoulderLanded, GemCollected, PlayerCrushed, ...
│  ├─ levels/                    # level .json + schema + solver.gd
│  ├─ scenes/                    # boot, main_menu, level, hub, journal, cutscenes
│  ├─ view/                      # LevelView: GridMap/MultiMesh sync, tick interpolation, camera
│  ├─ actors/                    # Nadia, enemies, boss visual scenes (AnimationTree)
│  ├─ vfx/                       # event→VFX router: pixelfx sprites, Effekseer, Jolt debris
│  ├─ audio/                     # event→SFX, adaptive music bus
│  ├─ ui/                        # HUD, touch controls, menus, journal (Control nodes)
│  ├─ platform/                  # save, billing, analytics, haptics (Android/iOS/Web adapters)
│  ├─ autoload/                  # Game.gd, Settings.gd, Save.gd, Events.gd (singletons)
│  ├─ addons/                    # gut, effekseer, terrain_3d, (voxel)
│  ├─ assets/                    # imported .glb, textures, sprite sheets, audio
│  └─ tests/                     # GUT tests + golden replays
├─ assets_src/                   # .blend, Material Maker .ptex, Effekseer .efkefc, audio stems
├─ tools/                        # pixelfx bake, level linter, noise bake scripts
├─ third_party/                  # the 10 cloned repos (reference/tooling; git-ignored)
└─ docs/
```

**Flow per frame:** `TouchInput → Game (fixed 10 Hz tick) → SimStep.step(state, intent) → events[]` →
`LevelView.sync(state, alpha)` + `VfxRouter.play(events)` + `AudioRouter.play(events)` + `Haptics`.
The sim never touches a Node. Nodes never change the sim state.

## Mobile rendering plan
- Each tile type is one `MultiMeshInstance3D` (or `GridMap` with a MeshLibrary), so one draw call each.
  Rooms outside the camera are hidden.
- Orthographic `Camera3D` tilted to 35°. Point lights for torches (≤ 8 visible), baked AO in vertex colour.
- Quality tiers: **Lite** (Compatibility renderer, no Jolt debris, 0.75 render scale) · **Standard** ·
  **High** (glow, tilt-shift DOF, colour LUT). Picked automatically from a benchmark on first boot.
- Pixel VFX are `AnimatedSprite3D` billboards with nearest filtering. This gives the "HD-2D" mix of crisp pixel
  effects over a smooth 3D world.
- Budgets: 60 fps on mid-range Android (Snapdragon 7-series), ≤ 120 draw calls, ≤ 400 MB RAM, base `.aab` ≤ 150 MB.

## Platform services
| Need | Android | iOS (later) | Web demo |
|---|---|---|---|
| Purchase | Godot Google Play Billing plugin | StoreKit plugin | "Get it on Google Play" link |
| Save | `user://` + optional Play Games cloud save | `user://` + iCloud | `user://` (IndexedDB) |
| Analytics | GameAnalytics or a self-hosted PostHog endpoint (privacy-first, consent in the EU) | same | same |
| Haptics | `Input.vibrate_handheld()` | same | none |

## Testing
- **Sim unit tests (GUT, headless):** one test per rule edge case.
- **Golden replays:** recorded inputs → expected state hash. They must match on every run and in CI.
- **Level solver:** a CI job proves every level is solvable and its gem quota reachable.
- **Device tests:** a weekly build on 3 reference phones (low, mid, high) with a frame-time log.
